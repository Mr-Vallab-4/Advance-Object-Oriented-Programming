public class PrintThree {
    public static void printThree(int num) {
        System.out.println("Divisible by 3: " + num);
    }
}
