public class PrintNumber {
    public static void printNumber(int num) {
        System.out.println("Not divisible by 2, 3, 4, or 5: " + num);
    }
}
