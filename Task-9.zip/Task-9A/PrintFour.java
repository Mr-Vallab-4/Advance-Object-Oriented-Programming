public class PrintFour {
    public static void printFour(int num) {
        System.out.println("Divisible by 4: " + num);
    }
}
