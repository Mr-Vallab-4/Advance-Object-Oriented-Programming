public class PrintTwo {
    public static void printTwo(int num) {
        System.out.println("Divisible by 2: " + num);
    }
}
