public class PrintFive {
    public static void printFive(int num) {
        System.out.println("Divisible by 5: " + num);
    }
}
